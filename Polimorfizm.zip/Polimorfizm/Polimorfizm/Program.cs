﻿using System.Runtime.CompilerServices;

namespace Polimorfizm.MojeKlasy;
internal class Program
{
    private static void Main(string[] args)
    {
        DateTime dt = new DateTime(1999, 2, 12);
        Klient klient1 = new Klient ("budtech", "Polska", "501552545",10000 );
        Console.WriteLine(klient1.ToString());
    }
}