﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Polimorfizm.MojeKlasy
{
    public class Klient 
    {
        public string Nazwa { get; set; }
        public string Kraj { get; set; }
        public string Nr_telefonu { get; set; }
        public decimal Kapital { get; set; }

        public Klient(string Nazwa, string Kraj, string Nr_telefonu, decimal Kapital)
        {
            this.Nazwa = Nazwa;
            this.Nr_telefonu = Nr_telefonu;
            this.Kraj = Kraj;
            this.Kapital = Kapital;
        }
        public override string ToString()
        {
            return Nazwa+ ", "+Kraj+ ", "+Kapital+ ", "+Nr_telefonu;
            
        }
        public decimal PoliczKapital(int liczbaMiesiecy)
        {
            decimal odsetki = 0.03m;
            decimal nowyKapital = Kapital;

            for (int i = 0; i < liczbaMiesiecy; i++)
            {
                nowyKapital += nowyKapital * odsetki;
            }

            return nowyKapital;
        }


    }
}
