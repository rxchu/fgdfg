﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Polimorfizm.MojeKlasy
{
    internal class KlientOsoba : Klient
    {
        public string Imie { get; set; }
        public string Nazwisko { get; set; }
        public DateTime DataUrodzenia { get; set; }

        public KlientOsoba(string imie, string nazwisko, DateTime dataUrodzenia,
            string Nazwa, string Kraj, string Nr_telefonu, decimal Kapital)
            : base(Nazwa, Kraj, Nr_telefonu, Kapital)
        {
            this.Imie = imie;
            this.Nazwisko = nazwisko;
            this.DataUrodzenia = dataUrodzenia;
        }

        public override string ToString()
        {
            return Imie + ", " + Nazwisko+ ", " + DataUrodzenia.ToString() + ", ";
        }
        public decimal PoliczKapital(decimal poczatkowyKapital, int okresTrwaniaMiesiace)
        {
            decimal odsetki = poczatkowyKapital * 0.02m * (decimal)okresTrwaniaMiesiace / 12m;
            decimal koncowyKapital = poczatkowyKapital + odsetki;
            return koncowyKapital;
        }
    }
}
 